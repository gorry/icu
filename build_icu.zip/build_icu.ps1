# build_icu.ps1
$ErrorActionPreference = "Stop"
$RootDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
$OriginalDir = Get-Location
$script:ExitCode = 0  # Default to success

# --- Function Definitions ---

# Function to clean a project
function Clean-Project {
    param(
        [string]$ProjectPath,
        [string]$Configuration,
        [string]$Platform
    )
    Write-Host "Cleaning $ProjectPath for $Configuration|$Platform..."
    & $msbuild $ProjectPath /t:Clean /p:Configuration=$Configuration /p:Platform=$Platform /m /v:m
    if ($LASTEXITCODE -ne 0) {
        throw "Failed to clean $ProjectPath for $Configuration|$Platform."
    }
}

# Function to build a project
function Build-Project {
    param(
        [string]$ProjectPath,
        [string]$Configuration,
        [string]$Platform
    )
    Write-Host "Building $ProjectPath for $Configuration|$Platform..."
    Write-Host "Output Binary Log: $ProjectPath.$Configuration.$Platform.binlog"
    & $msbuild $ProjectPath /p:Configuration=$Configuration /p:Platform=$Platform /m /v:m
    if ($LASTEXITCODE -ne 0) {
        throw "Failed to build $ProjectPath for $Configuration|$Platform."
    }
}

# Function to copy libraries
function Copy-Libraries {
    param(
        [string]$SourceDir,
        [string]$TargetLibDir,
        [string]$LibName
    )
    Write-Host "Copying $LibName from $SourceDir to $TargetLibDir..."
    Copy-Item -Path "$SourceDir\$LibName" -Destination $TargetLibDir -Force
}

# Function to copy executables
function Copy-Executables {
    param(
        [string]$SourceDir,
        [string]$TargetBinDir,
        [string]$ExeName
    )
    Write-Host "Copying $ExeName from $SourceDir to $TargetBinDir..."
    Copy-Item -Path "$SourceDir\$ExeName" -Destination $TargetBinDir -Force
}

# Function to copy headers
function Copy-Headers {
    param(
        [string]$SourceDir,
        [string]$TargetIncludeDir
    )
    Write-Host "Copying headers from $SourceDir to $TargetIncludeDir..."
    Copy-Item -Path "$SourceDir\*" -Destination $TargetIncludeDir -Recurse -Force
}

# --- Path and Variable Definitions ---

$msbuild = "D:\V\Microsoft Visual Studio\2022\Professional\MSBuild\Current\Bin\amd64\MSBuild.exe"

$icuSourceDir = "$RootDir\icu\icu4c\source"
$stubdataProject = "$icuSourceDir\stubdata\stubdata.vcxproj"
$commonProject = "$icuSourceDir\common\common.vcxproj"
$toolutilProject = "$icuSourceDir\tools\toolutil\toolutil.vcxproj"
$i18nProject = "$icuSourceDir\i18n\i18n.vcxproj"
$ioProject = "$icuSourceDir\io\io.vcxproj"
$derbProject = "$icuSourceDir\tools\genrb\derb.vcxproj"
$genrbProject = "$icuSourceDir\tools\genrb\genrb.vcxproj"

$installMTDir = "$RootDir\install_MT\icu"
$installMTdDir = "$RootDir\install_MTd\icu"


# --- Main Execution ---

try {
    # Cleaning Release Build

    Write-Host "`n--- Cleaning ICU intermediate build files using MSBuild ---"

    $projects = $stubdataProject, $commonProject, $toolutilProject, $i18nProject, $ioProject, $derbProject, $genrbProject

    foreach ($proj in $projects) {
        Clean-Project $proj "Release" "x64"
        Clean-Project $proj "Debug" "x64"
    }

    # Clean previous install directories
    Write-Host "Cleaning previous install directories..."
    Remove-Item -Path $installMTDir -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item -Path $installMTdDir -Recurse -Force -ErrorAction SilentlyContinue
    New-Item -ItemType Directory -Path "$installMTDir\lib", "$installMTDir\bin", "$installMTDir\include\unicode" -Force | Out-Null
    New-Item -ItemType Directory -Path "$installMTdDir\lib", "$installMTdDir\bin", "$installMTdDir\include\unicode" -Force | Out-Null

    # --- Release Build ---
    Write-Host "--- Starting Release Build (MT) ---"

    # Build core libraries for Release
    Build-Project $stubdataProject "Release" "x64"
    Build-Project $commonProject "Release" "x64"
    Build-Project $toolutilProject "Release" "x64"
    Build-Project $i18nProject "Release" "x64"
    Build-Project $ioProject "Release" "x64"

    # Copy Release libraries
    Copy-Libraries "$icuSourceDir\common\x64\Release" "$installMTDir\lib" "icuuc.lib"
    Copy-Libraries "$icuSourceDir\i18n\x64\Release" "$installMTDir\lib" "icuin.lib"
    Copy-Libraries "$icuSourceDir\tools\toolutil\x64\Release" "$installMTDir\lib" "icutu.lib"
    Copy-Libraries "$icuSourceDir\io\x64\Release" "$installMTDir\lib" "icuio.lib"
    Copy-Libraries "$icuSourceDir\stubdata\x64\Release" "$installMTDir\lib" "stubdata.lib"

    # Build tools for Release
    Build-Project $derbProject "Release" "x64"
    Build-Project $genrbProject "Release" "x64"

    # Copy Release executables
    Copy-Executables "$icuSourceDir\tools\genrb\x64\Release" "$installMTDir\bin" "derb.exe"
    Copy-Executables "$icuSourceDir\tools\genrb\x64\Release" "$installMTDir\bin" "genrb.exe"

    # --- Debug Build ---
    Write-Host "--- Starting Debug Build (MTd) ---"

    # Build core libraries for Debug
    Build-Project $stubdataProject "Debug" "x64"
    Build-Project $commonProject "Debug" "x64"
    Build-Project $toolutilProject "Debug" "x64"
    Build-Project $i18nProject "Debug" "x64"
    Build-Project $ioProject "Debug" "x64"

    # Copy Debug libraries
    Copy-Libraries "$icuSourceDir\common\x64\Debug" "$installMTdDir\lib" "icuuc.lib"
    Copy-Libraries "$icuSourceDir\i18n\x64\Debug" "$installMTdDir\lib" "icuin.lib"
    Copy-Libraries "$icuSourceDir\tools\toolutil\x64\Debug" "$installMTdDir\lib" "icutu.lib"
    Copy-Libraries "$icuSourceDir\io\x64\Debug" "$installMTdDir\lib" "icuio.lib"
    Copy-Libraries "$icuSourceDir\stubdata\x64\Debug" "$installMTdDir\lib" "stubdata.lib"

    # Build tools for Debug
    Build-Project $derbProject "Debug" "x64"
    Build-Project $genrbProject "Debug" "x64"

    # Copy Debug executables
    Copy-Executables "$icuSourceDir\tools\genrb\x64\Debug" "$installMTdDir\bin" "derb.exe"
    Copy-Executables "$icuSourceDir\tools\genrb\x64\Debug" "$installMTdDir\bin" "genrb.exe"

    # --- Copy Headers ---
    Write-Host "--- Copying Headers ---"
    Copy-Headers "$icuSourceDir\i18n\unicode" "$installMTDir\include\unicode"
    Copy-Headers "$icuSourceDir\common\unicode" "$installMTDir\include\unicode"
    Copy-Headers "$icuSourceDir\i18n\unicode" "$installMTdDir\include\unicode"
    Copy-Headers "$icuSourceDir\common\unicode" "$installMTdDir\include\unicode"

    Write-Host "ICU build process completed."

}
catch {
    Write-Host -ForegroundColor Red "`nAn error occurred during the build process."
    Write-Error $_.Exception.Message
    $script:ExitCode = 1
}
finally {
    Write-Host "`nReturning to the original directory: $($OriginalDir.Path)"
    Set-Location -Path $OriginalDir
}

exit $script:ExitCode