# build_icu.ps1

# Define MSBuild path
$msbuild = "D:\\V\\Microsoft Visual Studio\\2022\\Professional\\MSBuild\\Current\\Bin\\amd64\\MSBuild.exe"

# Define project paths
$icuSourceDir = "icu\\icu4c\\source"
$stubdataProject = "$icuSourceDir\\stubdata\\stubdata.vcxproj"
$commonProject = "$icuSourceDir\\common\\common.vcxproj"
$toolutilProject = "$icuSourceDir\\tools\\toolutil\\toolutil.vcxproj"
$i18nProject = "$icuSourceDir\\i18n\\i18n.vcxproj"
$ioProject = "$icuSourceDir\\io\\io.vcxproj"
$derbProject = "$icuSourceDir\\tools\\genrb\\derb.vcxproj"
$genrbProject = "$icuSourceDir\\tools\\genrb\\genrb.vcxproj"

# Define install directories
$installMTDir = "install_MT\\icu"
$installMTdDir = "install_MTd\\icu"

# Function to build a project
function Build-Project {
    param(
        [string]$ProjectPath,
        [string]$Configuration,
        [string]$Platform
    )
    Write-Host "Building $ProjectPath for $Configuration|$Platform..."
    & $msbuild $ProjectPath /p:Configuration=$Configuration /p:Platform=$Platform /m /v:m
    if ($LASTEXITCODE -ne 0) {
        Write-Error "Failed to build $ProjectPath for $Configuration|$Platform."
        exit $LASTEXITCODE
    }
}

# Function to copy libraries
function Copy-Libraries {
    param(
        [string]$SourceDir,
        [string]$TargetLibDir,
        [string]$LibName
    )
    Write-Host "Copying $LibName from $SourceDir to $TargetLibDir..."
    Copy-Item -Path "$SourceDir\\$LibName" -Destination $TargetLibDir -Force
    if ($LASTEXITCODE -ne 0) {
        Write-Error "Failed to copy $LibName."
        exit $LASTEXITCODE
    }
}

# Function to copy executables
function Copy-Executables {
    param(
        [string]$SourceDir,
        [string]$TargetBinDir,
        [string]$ExeName
    )
    Write-Host "Copying $ExeName from $SourceDir to $TargetBinDir..."
    Copy-Item -Path "$SourceDir\\$ExeName" -Destination $TargetBinDir -Force
    if ($LASTEXITCODE -ne 0) {
        Write-Error "Failed to copy $ExeName."
        exit $LASTEXITCODE
    }
}

# Function to copy headers
function Copy-Headers {
    param(
        [string]$SourceDir,
        [string]$TargetIncludeDir
    )
    Write-Host "Copying headers from $SourceDir to $TargetIncludeDir..."
    Copy-Item -Path "$SourceDir\\*" -Destination $TargetIncludeDir -Recurse -Force
    if ($LASTEXITCODE -ne 0) {
        Write-Error "Failed to copy headers."
        exit $LASTEXITCODE
    }
}

# Clean previous install directories
Write-Host "Cleaning previous install directories..."
Remove-Item -Path $installMTDir -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -Path $installMTdDir -Recurse -Force -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Path "$installMTDir\\lib", "$installMTDir\\bin", "$installMTDir\\include\\unicode" | Out-Null
New-Item -ItemType Directory -Path "$installMTdDir\\lib", "$installMTdDir\\bin", "$installMTdDir\\include\\unicode" | Out-Null

# --- Release Build ---
Write-Host "--- Starting Release Build (MT) ---"



# Build core libraries for Release
Build-Project $stubdataProject "Release" "x64"
Build-Project $commonProject "Release" "x64"
Build-Project $toolutilProject "Release" "x64"
Build-Project $i18nProject "Release" "x64"
Build-Project $ioProject "Release" "x64"

# Copy Release libraries
Copy-Libraries "$icuSourceDir\\common\\x64\\Release" "$installMTDir\\lib" "icuuc.lib"
Copy-Libraries "$icuSourceDir\\i18n\\x64\\Release" "$installMTDir\\lib" "icuin.lib"
Copy-Libraries "$icuSourceDir\\tools\\toolutil\\x64\\Release" "$installMTDir\\lib" "icutu.lib"
Copy-Libraries "$icuSourceDir\\io\\x64\\Release" "$installMTDir\\lib" "icuio.lib"
Copy-Libraries "$icuSourceDir\\stubdata\\x64\\Release" "$installMTDir\\lib" "stubdata.lib"

# Build tools for Release
Build-Project $derbProject "Release" "x64"
Build-Project $genrbProject "Release" "x64"

# Copy Release executables
Copy-Executables "$icuSourceDir\\tools\\genrb\\x64\\Release" "$installMTDir\\bin" "derb.exe"
Copy-Executables "$icuSourceDir\\tools\\genrb\\x64\\Release" "$installMTDir\\bin" "genrb.exe"

# --- Debug Build ---
Write-Host "--- Starting Debug Build (MTd) ---"



# Build core libraries for Debug
Build-Project $stubdataProject "Debug" "x64"
Build-Project $commonProject "Debug" "x64"
Build-Project $toolutilProject "Debug" "x64"
Build-Project $i18nProject "Debug" "x64"
Build-Project $ioProject "Debug" "x64"

# Copy Debug libraries
Copy-Libraries "$icuSourceDir\\common\\x64\\Debug" "$installMTdDir\\lib" "icuuc.lib"
Copy-Libraries "$icuSourceDir\\i18n\\x64\\Debug" "$installMTdDir\\lib" "icuin.lib"
Copy-Libraries "$icuSourceDir\\tools\\toolutil\\x64\\Debug" "$installMTdDir\\lib" "icutu.lib"
Copy-Libraries "$icuSourceDir\\io\\x64\\Debug" "$installMTdDir\\lib" "icuio.lib"
Copy-Libraries "$icuSourceDir\\stubdata\\x64\\Debug" "$installMTdDir\\lib" "stubdata.lib"

# Build tools for Debug
Build-Project $derbProject "Debug" "x64"
Build-Project $genrbProject "Debug" "x64"

# Copy Debug executables
Copy-Executables "$icuSourceDir\\tools\\genrb\\x64\\Debug" "$installMTdDir\\bin" "derb.exe"
Copy-Executables "$icuSourceDir\\tools\\genrb\\x64\\Debug" "$installMTdDir\\bin" "genrb.exe"

# --- Copy Headers ---
Write-Host "--- Copying Headers ---"
Copy-Headers "$icuSourceDir\\i18n\\unicode" "$installMTDir\\include\\unicode"
Copy-Headers "$icuSourceDir\\common\\unicode" "$installMTDir\\include\\unicode"
Copy-Headers "$icuSourceDir\\i18n\\unicode" "$installMTdDir\\include\\unicode"
Copy-Headers "$icuSourceDir\\common\\unicode" "$installMTdDir\\include\\unicode"

Write-Host "ICU build process completed."
